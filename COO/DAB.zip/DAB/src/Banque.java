import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("cc49a434-27a0-40d0-a577-6174a3ae3a5b")
public class Banque {
    @objid ("baa6c6ac-c757-4bc4-90ea-5079ea10856f")
    private String nomBanque;

    @objid ("5653bdb6-0c4e-497d-9858-78848fe5e6c9")
    private String codeBanque;

    @objid ("8cbb231f-0ca2-40d7-a93c-6ebb0980c4c5")
    public List<Banque> autresBanques = new ArrayList<Banque> ();

    @objid ("7404ecee-449b-4a85-b0a8-f7bb2337227d")
    private List<Client> listClient = new ArrayList<Client> ();

    @objid ("ba9dfe00-e9fb-4940-83b0-d59ba33ffbc1")
    private List<CarteClient> ListCarteClient = new ArrayList<CarteClient> ();

    @objid ("4d474a5a-273e-4d0c-b472-cb5e380f7255")
    private List<Compte> ListCompte = new ArrayList<Compte> ();

    @objid ("7e98eb37-285f-4101-9f98-3e5261f05350")
    public boolean estUnClient(String noCarte) {
    	return noCarte.startsWith(codeBanque);
    }

    @objid ("409a8b12-cca1-4dc5-9fe7-1b981a1d67ef")
    private List<Compte> recupereComptes(String noCarte) {
    }

    @objid ("b0292e8b-58d5-4d7a-b340-629759affbd3")
    public List<Compte> recupereComptesVirement(Client compteClient) {
    }

    @objid ("646d25db-7266-41ca-85aa-72ffd72cae7e")
    public boolean effectueVirement(Compte compteEmission, Compte compteDestinataire, double somme, Date date, String message) {
    }

    @objid ("d4ed8b97-5037-48bc-89a4-f3a69ad3d33e")
    public List<Compte> recupereComptesConsultation(String noCarte) {
    }

    @objid ("9d7dd4a9-cc66-407e-977a-68ae8811036e")
    private void recupereComptesDestinataire() {
    }

    @objid ("e9c3a1aa-b361-42f0-8d4d-5c60930879b6")
    public Banque(String nomBanque, String codeBanque) {
    }

}

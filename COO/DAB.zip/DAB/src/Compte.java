import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("87850a0f-5d60-4722-bb3d-ca023852cd42")
public class Compte {
    @objid ("191536ce-0266-408e-a557-46fb6acc98cf")
    private float Solde;

    @objid ("886794fc-3dc8-4e6e-b97a-7ddfe15dd88f")
    private String noCompte;

    @objid ("290984e3-86d4-4695-8f9f-54c3a99b0ef0")
    private float plafondRetrait;

    @objid ("d3c9cced-c1f6-4290-9ff8-b85697943c65")
    private List<Client> client = new ArrayList<Client> ();

    @objid ("00406ad2-6e05-42f2-8e88-2eb65ea541b6")
    private List<OperationBancaire> listOB = new ArrayList<OperationBancaire> ();

    @objid ("a9ff92bf-53cb-4fef-ae77-d4cdd037fd7b")
    public String afficheCompte() {
        return "noCompte : " + noCompte + "\n"
                            +  "Solde : " + Solde + "\n"
                            + "plafondRetrait : " + "\n";
    }

    @objid ("39dcc015-c719-4a2e-b363-ee951dd26c09")
    public Compte recupereCompte() {
    }

    @objid ("4812dc6d-b02b-437d-9640-514a681d14af")
    public String afficheCompteVirement() {
    }

    @objid ("5c15f794-7472-4d27-b33b-518af67dce2c")
    public boolean verifierVirementPossible(double somme, Date date) {
    }

    @objid ("954a4a42-c74d-496d-a25f-5d1978ee26e3")
    public Compte(float Solde, String noCompte, float plafondRetrait) {
    }

}

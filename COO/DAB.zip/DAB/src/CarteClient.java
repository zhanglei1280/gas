import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("320bd049-59c7-49a3-875a-6badb88241ce")
public class CarteClient {
    @objid ("e3f73978-e91a-47f7-9e14-c2c201927d48")
    private String noCarte;

    @objid ("8fbab064-f770-4e03-a963-86297443d7d7")
    private Client client;

    @objid ("aec7fa11-37aa-4f5b-8df1-f1c52c32d200")
    public boolean verifierNumeroCarte(String noCarte) {
    }

    @objid ("8dc224e6-fcac-469c-ac97-964c8f363a1e")
    public Client recupereClient() {
    }

    @objid ("d8d145ad-5d79-4a8b-807a-278ccd773d85")
    public CarteClient(String NoCarte) {
    }

}

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("983af6e6-0f2f-485b-969d-a5bb0437bc1d")
public class CompteDestinataire {
    @objid ("19296f0f-496f-4385-9532-aea3b4b7661d")
    private String Iban;

    @objid ("e17ca3f5-3fc3-415b-af90-017db0d968b8")
    private String BIC;

    @objid ("3af24602-c6a1-4811-a984-1aeb4c67fe70")
    public CompteDestinataire recupereCompte() {
    }

    @objid ("52f1f024-8fa2-4f96-a234-fbb61c3ad411")
    public String afficheCompte() {
        return "Iban : " + Iban + "\n" + "BIC : " + BIC;
    }

    @objid ("6f993fcc-d3a0-4255-b546-71c6427a3b1d")
    public CompteDestinataire(String Iban, String BIC) {
    }

}

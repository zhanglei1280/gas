import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("623c6fac-82a0-4936-8790-f546ce7701d9")
public class Carte {
    @objid ("9ff9cc69-f522-48cd-b5ee-b95d8a73f470")
    private String noCarte;

    @objid ("83bd55b3-cf67-4a89-bfdb-231a50909a53")
    private String code;

    @objid ("5b083c1a-2860-48a2-915e-9b6c412aa41b")
    private int nbEssaisRestant;

    @objid ("669d82cc-0a28-4209-8dd6-b043d2b81cb6")
    public boolean codeOK(String codeS) {
    }

    @objid ("653ec07a-4167-4a19-8788-d9ca91c2719d")
    public void getNoCarte() {
    }

    @objid ("ca44e17c-3c15-4d54-ac4b-2a2bf47a6500")
    public Carte(String noCarte, String code) {
    }

}

import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("3865dbe6-9a62-40d7-8389-3d87464ff109")
public class Client {
    @objid ("78d42978-1994-4850-966c-20a4389b667d")
    private List<CompteDestinataire> compteDestinataire = new ArrayList<CompteDestinataire> ();

    @objid ("1a3c3408-3618-41cf-acc4-7947649c4fad")
    private List<Compte> ListCompte = new ArrayList<Compte> ();

    @objid ("65221a5a-af87-443e-a70a-27066909a321")
    public List<Compte> recupereComptes() {
    }

    @objid ("e08a7997-b3cb-4272-bade-5883deb82096")
    public List<Compte> recupereComptesVirement() {
    }

    @objid ("9c987010-29f7-458c-a683-382238b43edd")
    public Client recupereClient() {
    }

    @objid ("c32aa06b-f393-467a-9006-562d3dff76d4")
    List<Compte> getListCompte() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.ListCompte;
    }

    @objid ("b2ad332b-6e7b-4126-8d27-30fd5feeabdb")
    void setListCompte(List<Compte> value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.ListCompte = value;
    }

    @objid ("39c6f4e2-cf9b-4320-9300-8498182f251f")
    public Client() {
    }

}

import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("3231ae30-a7f4-4829-b3d3-b56e2d78dbca")
public class OperationBancaire {
    @objid ("91260791-8615-4956-b0fa-12fa02578ee8")
    private NatureOperation nature;

    @objid ("89b06e46-9a93-4ec8-9fd1-bac427165fb8")
    private float Montant;

    @objid ("3e87b797-04ff-48cf-924e-85a330821674")
    private Date dateOperation;

    @objid ("4196b5f9-4a8c-4690-a278-1d298e6f5543")
    public void ajouteOperation(String nature, double montant, Date date) {
    }

    @objid ("cf1ebad2-aa9a-4491-b199-c79af67f71a1")
    public String afficheOB() {
    	return "NatureOperation : " + nature + "\n"
                    + "Montant : " + Montant + "\n"
                    + "dateOperation : " + dateOperation.toString() + "\n";
    }

    @objid ("d660cb80-155e-4aa8-a457-714b72f3eedc")
    public OperationBancaire(NatureOperation nature, float montant, Date dateOperation) {
    }

}

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("de7e3a8e-347b-4d18-9a5c-031c0ef91ae5")
public enum NatureOperation {
    Retrait,
    virement;
}
